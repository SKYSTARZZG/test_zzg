package com.calendar.service.impl;

import com.Notebook;
import com.calendar.mapper.NotebookMapper;
import com.calendar.service.NotebookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by moonstart on 2018/1/3.
 */
@Service
public class NotebookServiceImpl implements NotebookService{
    @Autowired
    private NotebookMapper notebookMapper;
    @Override
    public String createNewNote(Notebook notebook){
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        notebook.setCreatetime(sdf.format(new Date()));
        Integer num=this.notebookMapper.createNewNote(notebook);
        String str="";
        if(num==1){
            str="新事项添加成功。。。";
        }else{
            str="新事项添加失败。。。";
        }
        return  str;
    }

    @Override
    public Integer updateNoteById(Notebook notebook) {
        return this.notebookMapper.updateNoteById(notebook);
    }
    @Override
    public Integer deleteNoteById(Integer id){
        return this.notebookMapper.deleteNoteById(id);
    }

    @Override
    public List<Notebook> queryNotes(String period, String date) {
        String dateFormat = "";
        if(period.equals("month")){
            dateFormat="%Y-%m";
        }else if(period.equals("day")){
            dateFormat="%Y-%m-%d";
        }else {
            throw  new RuntimeException("period 參數錯誤");
        }
        return this.notebookMapper.queryNotes(dateFormat,date);
    }
}
