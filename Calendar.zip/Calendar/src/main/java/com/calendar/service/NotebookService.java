package com.calendar.service;

import com.Notebook;

import java.util.List;

/**
 * Created by moonstart on 2018/1/3.
 */
public interface NotebookService {
    String createNewNote(Notebook notebook);
    Integer updateNoteById(Notebook notebook);
    Integer deleteNoteById(Integer id);

    List<Notebook> queryNotes(String period, String date);
}
