package com.calendar.mapper;

import com.Notebook;
import org.apache.ibatis.annotations.*;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/**
 * Created by moonstart on 2018/1/3.
 */
@Mapper
public interface NotebookMapper {
    @Insert("insert into notebook(user_id,remind_time,title,note,createtime)values(#{userId}," +
            "#{remindTime},#{title},#{note},#{createtime})")
    Integer createNewNote(Notebook notebook);

    @Select("select id,user_id userId,remind_time remindTime,title,note,createtime " +
            "from notebook " +
            "where date_format(remind_time,'%Y-%m')='2018-01'")
    List<Notebook> queryNotesByMonth(String monthStr);
    @Update("update notebook set remind_time=#{remindTime},title=#{title}," +
            "note=#{note} where id=#{id}")
    Integer updateNoteById(Notebook notebook);
    @Delete("delete from notebook where id = #{id}")
    Integer deleteNoteById(Integer id);
    @Select("select id,user_id userId,remind_time remindTime,title,note,createtime " +
            "from notebook " +
            "where date_format(remind_time,#{dateFormat})=#{date}")
    List<Notebook> queryNotes(@Param("dateFormat") String dateFormat, @Param("date") String date);
}
