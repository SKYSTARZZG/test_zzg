package com.calendar.Model;

import lombok.Data;

/**
 * Created by moonstart on 2018/1/3.
 */
@Data
public class User {
    private Integer id;
    private String password;
    private String username;
    private String account;
}
