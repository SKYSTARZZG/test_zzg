package com.calendar.controller;

import com.Notebook;
import com.calendar.service.NotebookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.*;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import java.util.Base64;
import java.util.List;

/**
 * Created by moonstart on 2018/1/3.
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("notebook")
public class NotebookControler {

    @Autowired
    private NotebookService notebookService;
    @RequestMapping("test")
    public String test(){
        return "test spring boot!!!";
    }

    @ResponseBody
    @PostMapping("login")
    public String login(@RequestParam String loginCode,
                        @RequestParam String encryptedData,
                        @RequestParam String iv){
        final Base64.Decoder decoder=Base64.getDecoder();
     //   final String token = decoder.decode()


        return "";
    }


    @ResponseBody
    @PostMapping("newNote")
    public String createNewNote(@RequestBody Notebook notebook){
        notebook.setUserId(1);
        String str=this.notebookService.createNewNote(notebook);
        return str;
    }
    @ResponseBody
    @GetMapping("notes")
    public List<Notebook> queryNotesByMonth(@RequestParam("period") String period,
                                            @RequestParam("date")String date){
       return  this.notebookService.queryNotes(period,date);
    }
    @ResponseBody
    @PutMapping("newNote")
    public void updateNoteById(@RequestBody Notebook notebook){
        this.notebookService.updateNoteById(notebook);
    }
    @ResponseBody
    @DeleteMapping("/{id}")
    public String deleteNoteById(@PathVariable Integer id){
        Integer num=this.notebookService.deleteNoteById(id);
        String str=num==1?"删除成功。。。":"删除失败。。。";
        return str;
    }
}
