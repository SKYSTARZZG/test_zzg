package com;

import lombok.Data;

/**
 * Created by moonstart on 2018/1/3.
 */
@Data
public class Notebook {
    private Integer id;
    private Integer userId;
    private String remindTime;
    private String title;
    private String note;
    private String createtime;
}
